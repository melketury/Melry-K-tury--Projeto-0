import cv2

imagem = cv2.imread('gato.jpg')
print('Largura em pixels: ', end='')
print(imagem.shape[1]) 
print('Altura em pixels: ', end='')
print(imagem.shape[0]) 
print('Qtde de canais: ', end='')
print(imagem.shape[2])

cv2.imshow("Nome da janela", imagem)
cv2.waitKey(0) 

cv2.imwrite("saida.jpg", imagem)